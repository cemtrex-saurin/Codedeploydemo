#!/bin/bash
mkdir /home/ubuntu/my-app1
cd /home/ubuntu/my-app1
sudo npm install

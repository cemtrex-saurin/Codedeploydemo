# Basic-Node.js-Express-Server
> Basic test server application of Node.js with Express

To start the server typing follow command
````
npm index.js
````
